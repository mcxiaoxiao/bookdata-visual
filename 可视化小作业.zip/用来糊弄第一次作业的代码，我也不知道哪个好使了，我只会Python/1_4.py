import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取 CSV 文件
df = pd.read_csv('./ddf-data.csv')

# 设置字体为 SimHei（黑体），以支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置文字字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 提取 `exp_c1` 和 `exp_c2` 列，并处理缺失值
df_exp = df[['exp_c1', 'exp_c2']].dropna(subset=['exp_c1', 'exp_c2'])

# 将 `exp_c1` 和 `exp_c2` 转换为数值类型
df_exp['exp_c1'] = pd.to_numeric(df_exp['exp_c1'], errors='coerce')
df_exp['exp_c2'] = pd.to_numeric(df_exp['exp_c2'], errors='coerce')

# 删除无法转换为数值的行
df_exp = df_exp.dropna(subset=['exp_c1', 'exp_c2'])

# 处理异常值（可选）
def remove_outliers(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    return series[(series >= lower_bound) & (series <= upper_bound)]

df_exp_c1 = remove_outliers(df_exp['exp_c1'])
df_exp_c2 = remove_outliers(df_exp['exp_c2'])

# 设置直方图的区间数（bins 数量）
bin_count = 10  # 您可以根据需要调整区间数量

# 绘制直方图
plt.figure(figsize=(12, 6))

# 绘制 exp_c1 的直方图
plt.subplot(1, 2, 1)
plt.hist(df_exp_c1, bins=bin_count, edgecolor='black')
plt.title('第一次购买的直方图')
plt.xlabel('')
plt.ylabel('频数')
plt.grid(axis='y')  # 只显示横向网格线

# 绘制 exp_c2 的直方图
plt.subplot(1, 2, 2)
plt.hist(df_exp_c2, bins=bin_count, edgecolor='black')
plt.title('第二次购买的直方图')
plt.xlabel('值')
plt.ylabel('频数')
plt.grid(axis='y')  # 只显示横向网格线

plt.tight_layout()
plt.show()

print("直方图已生成。")
