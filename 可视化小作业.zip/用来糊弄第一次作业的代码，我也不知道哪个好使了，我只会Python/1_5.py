import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取 CSV 文件
df = pd.read_csv('./ddf-data.csv')

# 设置字体为 SimHei（黑体），以支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 提取需要的列，并处理缺失值
df_c1 = df[['trx_datime_c1', 'exp_c1']].dropna(subset=['trx_datime_c1', 'exp_c1'])
df_c2 = df[['trx_datime_c2', 'exp_c2']].dropna(subset=['trx_datime_c2', 'exp_c2'])

# 将日期列转换为日期类型
df_c1['trx_datime_c1'] = pd.to_datetime(df_c1['trx_datime_c1'], errors='coerce')
df_c2['trx_datime_c2'] = pd.to_datetime(df_c2['trx_datime_c2'], errors='coerce')

# 删除无法转换为日期的行
df_c1 = df_c1.dropna(subset=['trx_datime_c1'])
df_c2 = df_c2.dropna(subset=['trx_datime_c2'])

# 将金额列转换为数值类型
df_c1['exp_c1'] = pd.to_numeric(df_c1['exp_c1'], errors='coerce')
df_c2['exp_c2'] = pd.to_numeric(df_c2['exp_c2'], errors='coerce')

# 删除无法转换为数值的行
df_c1 = df_c1.dropna(subset=['exp_c1'])
df_c2 = df_c2.dropna(subset=['exp_c2'])

# 提取日期部分（年月日），舍弃时间部分
df_c1['date'] = df_c1['trx_datime_c1'].dt.date
df_c2['date'] = df_c2['trx_datime_c2'].dt.date

# 计算每天的销售总金额
# 第一次购买的销售额按日期汇总
sales_c1 = df_c1.groupby('date')['exp_c1'].sum().reset_index()
sales_c1.rename(columns={'exp_c1': 'sales'}, inplace=True)

# 第二次购买的销售额按日期汇总
sales_c2 = df_c2.groupby('date')['exp_c2'].sum().reset_index()
sales_c2.rename(columns={'exp_c2': 'sales'}, inplace=True)

# 合并两次购买的销售额数据
total_sales = pd.concat([sales_c1, sales_c2], ignore_index=True)

# 按日期汇总总销售额
total_sales = total_sales.groupby('date')['sales'].sum().reset_index()

# 按日期排序
total_sales = total_sales.sort_values('date').reset_index(drop=True)

# **导出到 Excel 文件**
# 将数据导出到 Excel 文件，包含两列：'date' 和 'sales'
output_filename = 'daily_total_sales.xlsx'
total_sales.to_excel(output_filename, index=False)
print(f"\n每天的销售总金额数据已导出到文件：{output_filename}")

# 绘制折线图
plt.figure(figsize=(12, 6))
plt.plot(total_sales['date'], total_sales['sales'], marker='o')

plt.xlabel('日期', fontsize=12)
plt.ylabel('销售总金额', fontsize=12)
plt.title('每天的销售总金额', fontsize=16)
plt.xticks(rotation=45)
plt.grid(axis='y')  # 只显示横向网格线

plt.tight_layout()
plt.show()

print("折线图已生成。")
