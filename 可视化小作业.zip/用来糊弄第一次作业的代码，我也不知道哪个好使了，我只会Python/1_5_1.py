import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取 CSV 文件
df = pd.read_csv('./ddf-data.csv')

# 设置字体为 SimHei（黑体），以支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 提取需要的列，并处理缺失值
df_c1 = df[['trx_datime_c1', 'exp_c1']].dropna(subset=['trx_datime_c1', 'exp_c1'])
df_c2 = df[['trx_datime_c2', 'exp_c2']].dropna(subset=['trx_datime_c2', 'exp_c2'])

# 创建日期时间列的副本，确保在转换失败后可以使用原始的字符串数据
df_c1['trx_datime_c1_orig'] = df_c1['trx_datime_c1']
df_c2['trx_datime_c2_orig'] = df_c2['trx_datime_c2']

# 方法一：调整日期时间格式匹配
try:
    # 将日期时间列转换为日期时间类型，调整格式
    df_c1['trx_datime_c1'] = pd.to_datetime(df_c1['trx_datime_c1'], errors='raise', format='%Y-%m-%d %H:%M:%S.%f')
    df_c2['trx_datime_c2'] = pd.to_datetime(df_c2['trx_datime_c2'], errors='raise', format='%Y-%m-%d %H:%M:%S.%f')

except Exception as e:
    print("\n日期时间转换失败，错误信息：", e)
    print("\n尝试使用字符串裁剪方法提取日期和小时。")

    # 使用原始的字符串列
    df_c1['trx_datime_c1'] = df_c1['trx_datime_c1_orig']
    df_c2['trx_datime_c2'] = df_c2['trx_datime_c2_orig']

    # 确保日期时间列为字符串类型并去除首尾空格
    df_c1['trx_datime_c1'] = df_c1['trx_datime_c1'].astype(str).str.strip()
    df_c2['trx_datime_c2'] = df_c2['trx_datime_c2'].astype(str).str.strip()

    # 提取日期部分（前10个字符）
    df_c1['date_str'] = df_c1['trx_datime_c1'].str.slice(0, 10)
    df_c2['date_str'] = df_c2['trx_datime_c2'].str.slice(0, 10)

    # 提取小时部分
    df_c1['hour_str'] = df_c1['trx_datime_c1'].str.slice(11, 13)
    df_c2['hour_str'] = df_c2['trx_datime_c2'].str.slice(11, 13)

    # 将日期字符串转换为日期对象
    df_c1['date'] = pd.to_datetime(df_c1['date_str'], format='%Y-%m-%d', errors='coerce').dt.date
    df_c2['date'] = pd.to_datetime(df_c2['date_str'], format='%Y-%m-%d', errors='coerce').dt.date

    # 将小时字符串转换为整数
    df_c1['hour'] = pd.to_numeric(df_c1['hour_str'], errors='coerce')
    df_c2['hour'] = pd.to_numeric(df_c2['hour_str'], errors='coerce')

    # 删除无法转换为日期或小时的行
    df_c1 = df_c1.dropna(subset=['date', 'hour', 'exp_c1'])
    df_c2 = df_c2.dropna(subset=['date', 'hour', 'exp_c2'])

# 如果方法一成功，直接提取日期和小时
else:
    # 提取日期和小时
    df_c1['date'] = df_c1['trx_datime_c1'].dt.date
    df_c1['hour'] = df_c1['trx_datime_c1'].dt.hour

    df_c2['date'] = df_c2['trx_datime_c2'].dt.date
    df_c2['hour'] = df_c2['trx_datime_c2'].dt.hour

# 将金额列转换为数值类型
df_c1['exp_c1'] = pd.to_numeric(df_c1['exp_c1'], errors='coerce')
df_c2['exp_c2'] = pd.to_numeric(df_c2['exp_c2'], errors='coerce')

# 删除无法转换为数值的行
df_c1 = df_c1.dropna(subset=['exp_c1'])
df_c2 = df_c2.dropna(subset=['exp_c2'])

# 定义目标日期范围
start_date = pd.to_datetime('2015-10-18').date()
end_date = pd.to_datetime('2015-10-24').date()

# 过滤出指定日期范围内的数据
df_c1 = df_c1[(df_c1['date'] >= start_date) & (df_c1['date'] <= end_date)]
df_c2 = df_c2[(df_c2['date'] >= start_date) & (df_c2['date'] <= end_date)]

# 合并两次购买的数据
df_c1.rename(columns={'exp_c1': 'sales'}, inplace=True)
df_c2.rename(columns={'exp_c2': 'sales'}, inplace=True)
df_all = pd.concat([df_c1[['date', 'hour', 'sales']], df_c2[['date', 'hour', 'sales']]], ignore_index=True)

# 按日期和小时汇总销售额
total_sales = df_all.groupby(['date', 'hour'])['sales'].sum().reset_index()

# 生成完整的日期和小时组合
date_range = pd.date_range(start=start_date, end=end_date, freq='D').date
hour_range = range(24)
all_dates_hours = pd.MultiIndex.from_product([date_range, hour_range], names=['date', 'hour']).to_frame(index=False)

# 将汇总数据与完整的日期和小时组合进行合并，缺失的销售额填充为0
total_sales = pd.merge(all_dates_hours, total_sales, on=['date', 'hour'], how='left').fillna(0)

# 按日期和小时排序
total_sales = total_sales.sort_values(['date', 'hour']).reset_index(drop=True)

# 检查最终的总销售额数据
print("\n2015-10-18 至 2015-10-24 每小时的总销售额：\n", total_sales.head(24))  # 显示前一天的数据

# **导出到 Excel 文件**
# 将数据导出到 Excel 文件，包含三列：'date'、'hour' 和 'sales'
output_filename = 'total_sales_2015-10-18_to_2015-10-24.xlsx'
total_sales.to_excel(output_filename, index=False)
print(f"\n总销售额数据已导出到文件：{output_filename}")

# 绘制折线图
plt.figure(figsize=(15, 7))
plt.plot(total_sales.index, total_sales['sales'], marker='o')

# 设置 x 轴标签为日期和小时
x_labels = total_sales['date'].astype(str) + ' ' + total_sales['hour'].astype(str) + '时'
plt.xticks(total_sales.index[::6], x_labels[::6], rotation=45)  # 每隔6个点显示一个标签

plt.xlabel('日期和小时', fontsize=12)
plt.ylabel('销售总金额', fontsize=12)
plt.title('2015-10-18 至 2015-10-24 每小时销售总金额', fontsize=16)
plt.grid(axis='y')

plt.tight_layout()
plt.show()

print("折线图已生成。")
