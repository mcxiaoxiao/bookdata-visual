import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取 CSV 文件
df = pd.read_csv('./ddf-data.csv')

# 设置字体为 SimHei（黑体），以支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 提取需要的列
df_purchase = df[['exp_c1', 'exp_c2']]

# 将金额列转换为数值类型
df_purchase['exp_c1'] = pd.to_numeric(df_purchase['exp_c1'], errors='coerce')
df_purchase['exp_c2'] = pd.to_numeric(df_purchase['exp_c2'], errors='coerce')

# 删除无法转换为数值的行或缺失值
df_purchase = df_purchase.dropna(subset=['exp_c1', 'exp_c2'])

# 检查处理后的数据
print("处理后的数据（前5行）：\n", df_purchase.head())

# 绘制散点图
plt.figure(figsize=(10, 6))
plt.scatter(df_purchase['exp_c1'], df_purchase['exp_c2'], alpha=0.6)

plt.xlabel('第一次购买金额', fontsize=12)
plt.ylabel('第二次购买金额', fontsize=12)
plt.title('第一次购买金额与第二次购买金额的关系', fontsize=16)
plt.grid(True)


plt.tight_layout()
plt.show()

print("散点图已生成。")
