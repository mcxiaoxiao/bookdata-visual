import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取 CSV 文件
df = pd.read_csv('./ddf-data.csv')

# 设置字体为 SimSun（宋体），以支持中文显示
plt.rcParams['font.sans-serif'] = ['SimSun']  # 设置字体为宋体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
plt.rcParams['font.size'] = 14  # 增大字体大小


# 提取 `exp_c1` 和 `exp_c2` 列，并处理缺失值
df_exp = df[['exp_c1', 'exp_c2']].dropna(subset=['exp_c1', 'exp_c2'])

# 将 `exp_c1` 和 `exp_c2` 转换为数值类型
df_exp['exp_c1'] = pd.to_numeric(df_exp['exp_c1'], errors='coerce')
df_exp['exp_c2'] = pd.to_numeric(df_exp['exp_c2'], errors='coerce')

# 删除无法转换为数值的行
df_exp = df_exp.dropna(subset=['exp_c1', 'exp_c2'])

# 重命名列名
df_exp.rename(columns={'exp_c1': '第一次购物', 'exp_c2': '第二次购物'}, inplace=True)

# 处理异常值（可选）
def remove_outliers(df, column):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    return df[(df[column] >= lower_bound) & (df[column] <= upper_bound)]

df_exp_c1 = remove_outliers(df_exp, '第一次购物')
df_exp_c2 = remove_outliers(df_exp, '第二次购物')

# 为了在箱线图中同时显示，需要对齐索引
df_filtered = pd.DataFrame({
    '第一次购物': df_exp_c1['第一次购物'],
    '第二次购物': df_exp_c2['第二次购物']
}).dropna()

# 绘制箱线图
plt.figure(figsize=(8, 6))

# 设置箱线图的属性
df_filtered.boxplot(
    column=['第一次购物', '第二次购物'],
    grid=False,
)

plt.title('箱线图')
plt.ylabel('金额')

# 只显示横向的格子
plt.grid(axis='y', color='gray', linestyle='--', linewidth=0.5)

# 设置坐标轴的颜色
ax = plt.gca()  # 获取当前坐标轴
ax.spines['bottom'].set_color('lightgray')  # x轴
ax.spines['left'].set_color('lightgray')    # y轴
ax.spines['top'].set_color('none')          # 隐藏顶部边框
ax.spines['right'].set_color('none')        # 隐藏右侧边框

# 显示箱线图
plt.show()

print("箱线图已生成。")
