/* eslint-disable */


import { atom } from 'recoil';

// 自定义 effect，用于持久化 atom 到 localStorage
const localStorageEffect = key => ({ setSelf, onSet }) => {
  const savedValue = localStorage.getItem(key);
  if (savedValue !== null) {
    try {
      setSelf(JSON.parse(savedValue));
    } catch (e) {
      console.error(`Error parsing JSON from localStorage for key "${key}":`, e);
    }
  }

  onSet(newValue => {
    if (newValue === undefined) {
      localStorage.removeItem(key);
    } else {
      localStorage.setItem(key, JSON.stringify(newValue));
    }
  });
};

// 创建 atom，并应用自定义的 localStorage effect
export const userID = atom({
  key: 'userID', // 注意这里的 key 应该是唯一的
  default: 10086,
  effects_UNSTABLE: [
    localStorageEffect('userID'),
  ],
});

// export const textState = atom({
//   key: 'textState', // unique ID (with respect to other atoms/selectors)
//   default: '', // default value (aka initial value)
// });



