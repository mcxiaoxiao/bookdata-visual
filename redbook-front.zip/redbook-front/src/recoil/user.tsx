/* eslint-disable */
import { atom } from 'recoil';

const localStorageEffect = key => ({ setSelf, onSet }) => {
  const savedValue = localStorage.getItem(key);
  if (savedValue !== null) {
    try {
      setSelf(JSON.parse(savedValue));
    } catch (e) {
      console.error(`Error parsing JSON from localStorage for key "${key}":`, e);
    }
  }

  onSet(newValue => {
    if (newValue === undefined) {
      localStorage.removeItem(key);
    } else {
      localStorage.setItem(key, JSON.stringify(newValue));
    }
  });
};

// 创建 atom，并应用自定义的 localStorage effect
export const userState = atom({
  key: 'userState', // 注意这里的 key 应该是唯一的
  default: null,
  effects_UNSTABLE: [
    localStorageEffect('userState'),
  ],
});
