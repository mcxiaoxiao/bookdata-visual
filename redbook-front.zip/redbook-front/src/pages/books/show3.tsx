/* eslint-disable */
import React, { FC, useEffect } from "react";
import * as echarts from 'echarts';
import { gql, useQuery } from "@apollo/client";

const A3 = gql`
  query FindA3All($id: Int!) {
    findA3All(id: $id) {
      name
      value
    }
  }
`;

const Book: FC = () => {
  const { data: data3, loading, error } = useQuery(A3, {
    variables: { id: 1 },
    onCompleted(data3) {
      console.log(data3);
    },
    onError(error) {
      console.error(error);
    },
  });

  if (loading) return <p>加载中...</p>;
  if (error) return <p>出错了: {error.message}</p>;

  // 假设 data3.findA3All 包含至少8个项目
  const groupedData: { category: string, series1: number, series2: number }[] = [];
  
  // 按每两项分组
  for (let i = 0; i < (data3?.findA3All.length || 0); i += 2) {
    const item1 = data3.findA3All[i];
    const item2 = data3.findA3All[i + 1];
    if (item1 && item2) {
      groupedData.push({
        category: `${item1.name}`,
        series1: item1.value,
        series2: item2.value,
      });
    }
  }

  const option3 = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
    },
    legend: {
      data: ['参与活动人群', '未参与活动人群'],
    },
    toolbox: {
      show: true,
      feature: {
        dataView: { show: true, readOnly: false },
        magicType: { show: true, type: ['line', 'bar'] },
        restore: { show: true },
        saveAsImage: { show: true },
      },
    },
    xAxis: [
      {
        type: 'category',
        data: groupedData.map(item => item.category),
      },
    ],
    yAxis: [
      {
        type: 'value',
      },
    ],
    series: [
      {
        name: '参与活动人群',
        type: 'bar',
        data: groupedData.map(item => item.series1),
        markPoint: {
          data: [
            { type: 'max', name: 'Max' },
            { type: 'min', name: 'Min' },
          ],
        },
        markLine: {
          data: [{ type: 'average', name: 'Avg' }],
        },
      },
      {
        name: '未参与活动人群',
        type: 'bar',
        data: groupedData.map(item => item.series2),
        markPoint: {
          data: [
            { type: 'max', name: 'Max' },
            { type: 'min', name: 'Min' },
          ],
        },
        markLine: {
          data: [{ type: 'average', name: 'Avg' }],
        },
      },
    ],
  };

  useEffect(() => {
    let chartInstance: echarts.ECharts | null = null;

    const chartDom = document.getElementById('A3');
    if (chartDom) {
      chartInstance = echarts.init(chartDom);
      chartInstance.setOption(option3);
    }

    // 监听窗口大小变化，响应式调整图表
    const handleResize = () => {
      if (chartInstance) {
        chartInstance.resize();
      }
    };
    window.addEventListener('resize', handleResize);

    // 清理函数
    return () => {
      if (chartInstance) {
        chartInstance.dispose();
      }
      window.removeEventListener('resize', handleResize);
    };
  }, [option3]); // 依赖项仅为 option3

  return (
    <div>
      <div style={{ display: 'flex' }}>
        <span style={{ flex: 1 }}>
          <div id="A3" style={{ width: '100%', height: '420px' }}></div>
          <div style={{ textAlign: 'center', marginTop: '10px' }}>活动消费统计双重柱状图 单位：元</div>
        </span>
      </div>
    </div>
  );
};

export default Book;
