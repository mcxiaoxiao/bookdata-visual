/* eslint-disable */
import React, { FC, useEffect } from "react";
import * as echarts from 'echarts';
import { gql, useQuery } from "@apollo/client";

const A1 = gql`
  query FindA1All($id: Int!) {
    findA1All(id: $id) {
      name
      value
    }
  }
`;
const A2 = gql`
  query FindA2All($id: Int!) {
    findA2All(id: $id) {
      name
      value
    }
  }
`;
const A3 = gql`
  query FindA3All($id: Int!) {
    findA3All(id: $id) {
      name
      value
    }
  }
`;
const A4 = gql`
  query FindA4All($id: Int!) {
    findA4All(id: $id) {
      name
      value
    }
  }
`;
const A5 = gql`
  query FindA5All($id: Int!) {
    findA5All(id: $id) {
      name
      value
    }
  }
`;
const A6 = gql`
  query FindA6All($id: Int!) {
    findA6All(id: $id) {
      name
      value
    }
  }
`;

const Book: FC = () => {
  const { data } = useQuery(A1, {
    variables: { id: 1 },
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.error(error);
    },
  });
  const { data: data2 } = useQuery(A2, {
    variables: { id: 1 },
    onCompleted(data2) {
      console.log(data2);
    },
    onError(error) {
      console.error(error);
    },
  });
  const { data: data3 } = useQuery(A3, {
    variables: { id: 1 },
    onCompleted(data3) {
      console.log(data3);
    },
    onError(error) {
      console.error(error);
    },
  });
  const { data: data4 } = useQuery(A4, {
    variables: { id: 1 },
    onCompleted(data4) {
      console.log(data4);
    },
    onError(error) {
      console.error(error);
    },
  });
  const { data: data5 } = useQuery(A5, {
    variables: { id: 1 },
    onCompleted(data5) {
      console.log(data5);
    },
    onError(error) {
      console.error(error);
    },
  });
  const { data: data6 } = useQuery(A6, {
    variables: { id: 1 },
    onCompleted(data6) {
      console.log(66666666666666666);
      console.log(data6);
    },
    onError(error) {
      console.error(error);
    },
  });

  const option2 = {
    tooltip: {
      trigger: 'item'
    },
    legend: {
      top: '1%',
      left: 'left'
    },
    series: [
      {
        name: '图书类别统计',
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: false,
          position: 'center'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 40,
            fontWeight: 'bold'
          }
        },
        labelLine: {
          show: false
        },
        data:
          data2?.findA2All.map((item) => ({
            value: item.value,
            name: item.name
          })) || []
      }
    ]
  };

  const option3 = {
    grid: {
      left: '15%',
    },
    xAxis: {
      type: 'value'
    },
    yAxis: {
      type: 'category',
      data: data5?.findA5All.map(item => item.name).reverse() || [],
    },
    series: [
      {
        data: data5?.findA5All.map(item => item.value).reverse() || [],
        type: 'bar'
      }
    ]
  };
  

  useEffect(() => {
    let B2 = null;
    let B3 = null;

    // Chart A2
    const A2 = document.getElementById('A2');
    if (A2) {
      B2 = echarts.init(A2);
      B2.setOption(option2);
    }

    // Chart A3
    const A3 = document.getElementById('A3');
    if (A3) {
      B3 = echarts.init(A3);
      B3.setOption(option3);
    }

    // Cleanup function
    return () => {
      if (B2) B2.dispose();
      if (B3) B3.dispose();
    };
  }, [data, data2, data3, data4, data5, data6]); // When data changes, re-render charts

  return (
    <div>
      <div style={{ display: 'flex' }}>

        <span>
          <div id="A3" style={{ width: '1100px', height: '420px' }}></div>
          <div style={{ textAlign: 'center', marginTop: '0px' }}>热门图书排名统计条形图</div>
        </span>
      </div>
    </div>
  );
  
};

export default Book;
