/* eslint-disable */
import React, { FC, useState,useEffect } from 'react';
import { Button, Table, Modal, Select, Input, message,Form,InputNumber } from 'antd';
import { gql, useQuery,useMutation } from '@apollo/client';
import { CodeSandboxOutlined } from '@ant-design/icons';

import {
  BookOutlined,
  ReadOutlined,
  LaptopOutlined,
  CalendarOutlined,
  TeamOutlined,
  HeartOutlined,
  HeartFilled
  
} from '@ant-design/icons';
import {
  PlusCircleOutlined
 
  
} from '@ant-design/icons';

const { Option } = Select;

const{TextArea} = Input;

const gradientBackground = {
  background: 'linear-gradient(to right, #8a4dff, #ff6bfe)',
  borderRadius: '20px',
  width: '97%',
  height: '120px',
  margin: '20px',
  marginTop: '10px',
  marginBottom: '30px',
  border: '1px solid #e3d4ff',
  backgroundImage: 'linear-gradient(to bottom right, #8a4dff, #ff6bfe)',
  transition: 'border-color 0.3s ease-in-out',
};

const inputStyle = {
  borderRadius: '20px',
  width: '70%',
  left:'5%',
  height: 50,
  background:'white',
  top:30,
  marginRight: '10px',
};

const buttonStyle = {
  borderRadius: '50%',
  width: 60,
  top:30,
  height: 60,
};

const Favo: FC = () => {
  const [messageApi, contextHolder] = message.useMessage();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible2, setModalVisible2] = useState(false);

  const [selectedBook, setSelectedBook] = useState(null);
  const [datashow, setDatashow] = useState([]);
  const [favo, setFavo] = useState([]);

  const [filterValue, setFilterValue] = useState('');
  const [searchValue, setSearchValue] = useState('');
  const [text, setText] = useState('');



  const FIND_A = gql`
    query FindBookAll($pageNumber: Int!, $pageSize: Int!) {
      findFavoAll(pageNumber: $pageNumber, pageSize: $pageSize) {
        list {
          bookid
          author
          level
          type
          borrowed
          isbn
          content
          libid
          name
          price
          publisher
          libname
        }
        totalCount
      }
    }
  `;


  const FIND = gql`
    query FindBookAll($pageNumber: Int!, $pageSize: Int!) {
      findBookAll(pageNumber: $pageNumber, pageSize: $pageSize) {
        list {
          bookid
          author
          level
          type
          borrowed
          isbn
          content
          libid
          name
          price
          publisher
          libname
        }
        totalCount
      }
    }
  `;

const DELETE = gql`
mutation Delete($id: Int!) {
  deleteFavo(id: $id) {
    bookid
    author
    level
    type
    borrowed
    isbn
    content
    libid
    name
    price
    publisher
    libname
  }
}
`;

const ADD = gql`
mutation add($book: BookEntityInput!) {
  addBook(book:$book) {
    type
    name
    author
    bookid
    level
  }
}
`;

const [del] = useMutation(DELETE);
const [add] = useMutation(ADD);



  // 第一个查询：获取收藏数据
  const { refetch: re, data: un } = useQuery(FIND_A, {
    variables: { pageNumber: 1, pageSize: `100000` },
    onCompleted(data) {
      const filteredData = data.findFavoAll.list;
      setFavo(filteredData);
      console.log(filteredData);
    },
    onError(error) {
      console.error(error);
    },
  });

  // 第二个查询：获取所有书籍数据
  const { refetch, loading } = useQuery(FIND, {
    variables: { pageNumber: 1, pageSize: `100000` },
    onCompleted(data) {
      console.log('书籍');
      console.log(data);

      if (favo.length > 0) {
        const filteredData = data.findBookAll.list.filter(book =>
          favo.some(f => f.isbn === book.isbn)
        );
        setDatashow(filteredData);
        console.log(filteredData);
      }
    },
    onError(error) {
      console.error(error);
    },
  });

  // 使用 useEffect 确保在 favo 更新后重新过滤书籍数据
  useEffect(() => {
    if (un && !loading && favo.length > 0) {
      refetch();
    }
  }, [favo]);


  const handleRefetch = async () => {
    try {
      // 首先重新获取收藏数据
      const { data: favoData } = await re();
      if (favoData && favoData.findFavoAll && favoData.findFavoAll.list) {
        const filteredFavoData = favoData.findFavoAll.list;
        setFavo(filteredFavoData);
  
        // 然后重新获取所有书籍数据
        const { data: bookData } = await refetch();
        if (bookData && bookData.findBookAll && bookData.findBookAll.list) {
          const filteredBookData = bookData.findBookAll.list.filter(book =>
            filteredFavoData.some(f => f.isbn === book.isbn)
          );
          setDatashow(filteredBookData);
        } else {
          console.error("Unexpected refetched book data structure:", bookData);
        }
      } else {
        console.error("Unexpected refetched favo data structure:", favoData);
      }
    } catch (error) {
      console.error("Error during refetch:", error);
    }
  };
  

  const columns = [
    
    {
      title: '图书馆名称',
      dataIndex: 'libname',
      key: 'libname',
      filters: [
        { text: '西区', value: '西区' },
        { text: '南区', value: '南区' },
      ],
      onFilter: (value, record) => record.libname === value,
      render: (text) => <span>{text}</span>,
    },
    {
      title: '书名',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '作者',
      dataIndex: 'author',
      key: 'author',
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'ISBN',
      dataIndex: 'isbn',
      key: 'isbn',
    },
    
    {
      title: '价格',
      dataIndex: 'price',
      key: 'price',
    },
    {
      title: '出版社',
      dataIndex: 'publisher',
      key: 'publisher',
    },
    {
      title: '内容',
      dataIndex: 'content',
      key: 'content',
    },
    {
      title: '  ',
      key: 'actions',
      fixed: 'right',
      align: 'center', 
      width:50,
      render: (_, record) => (
        <Button 
        type="link" 
        onClick={() => handleDelete(record)} 
        style={{ padding: 0, border: 'none', boxShadow: 'none' }}
      >
        <HeartFilled style={{ color: 'red' , fontSize: '20px'}} />
      </Button>
      ),
    },

    {
      title: '',
      fixed: 'right',
      dataIndex: 'borrowed',
      align: 'center', 
      key: 'borrowed',
      width:100,
      render: (borrowed) => <span>{borrowed ? '已被借出' : '当前在库'}</span>,
    },
  ];

  const handleDeleteTrue = async () => {

    const matchingNode = favo.find(book => book.isbn === selectedBook?.isbn);
    try {
      const { data } = await del({
        variables: { 
          id: matchingNode?.bookid
        },
      });
      if (data) {
        setModalVisible2(false);
        messageApi.open({
          type: 'success',
          content: '删除成功',
        });
        console.log("删除成功")

        handleRefetch()
      }
    } catch (error: unknown) {
      if (error instanceof Error) {
        setModalVisible2(false);
        messageApi.open({
          type: 'error',
          content: '删除失败',
        });
        console.log(error)
      }
    }
  };

  const handleDelete = (record) => {
    setSelectedBook(record);
    setModalVisible2(true);
  };

  const handleDeleteCancel = () => {
    setModalVisible2(false);
  };

  return (
    <div >
{contextHolder}

      <Table
        columns={columns}
        dataSource={datashow}
        loading={loading}
        scroll={{ x: 'max-content' }}
      />
      <Modal
        title="取消收藏"
        visible={modalVisible2}
        onCancel={handleDeleteCancel}
        footer={[
          <Button key="cancel" onClick={handleDeleteCancel}>
            取消
          </Button>,
          <Button key="borrow" type="primary" onClick={handleDeleteTrue}>
            删除
          </Button>,
        ]}
      >
        {/* Modal content here */}
        {selectedBook && (
          <div>
            <p>图书名称：{selectedBook.name}</p>
            <p>你确定要取消收藏?</p>
            {/* Add more book details as needed */}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Favo;
