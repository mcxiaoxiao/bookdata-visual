import React from 'react';
import {
  ReadOutlined,
  TeamOutlined,
  UserOutlined,
  AndroidOutlined,
} from '@ant-design/icons';
import type { MenuProps } from 'antd';
import { Outlet, useNavigate } from 'react-router-dom';
import { Breadcrumb, Layout, Menu, theme } from 'antd';
import { useState, FC } from 'react';

import { userID } from '../../recoil/store';
import { userState } from '../../recoil/user';

import { useRecoilState } from 'recoil';

const MenuLayout: React.FC = () => {
  const [ID, setID] = useRecoilState(userID);
  const nav = useNavigate();
  const [userInfo, setUserInfo] = useRecoilState(userState); // 使用新的 atom

  const [currentPage, setCurrentPage] = useState(1);

  // 导航函数
  const navigateTo = (path: string, page: number) => {
    nav(path);
    setCurrentPage(page);
  };

  const { Header, Content, Footer, Sider } = Layout;

  type MenuItem = Required<MenuProps>['items'][number];
  
  const getItem = (
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    onClick?: () => void,
    children?: MenuItem[],
    type?: 'group',
  ): MenuItem => {
    return {
      key,
      icon,
      onClick,
      children,
      label,
      type,
    } as MenuItem;
  };

  const items: MenuItem[] = [
    getItem('数据一览', '1', <ReadOutlined />, undefined, [
      getItem('消费区间分析', '1-1', <ReadOutlined />, () => navigateTo('/show1', 1)),
      getItem('消费人群统计', '1-2', <ReadOutlined />, () => navigateTo('/show2', 2)),
      getItem('活动消费统计', '1-3', <ReadOutlined />, () => navigateTo('/show3', 3)),
      getItem('第三方消费分析', '1-4', <ReadOutlined />, () => navigateTo('/show4', 4)),
      getItem('购物时区分析', '1-5', <ReadOutlined />, () => navigateTo('/show5', 5)),
    ]),
    getItem('用户管理', '8', <TeamOutlined />, () => navigateTo('/user', 8)),
    getItem('个人信息', '7', <UserOutlined />, () => navigateTo('/reader', 7)),
  ];

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  return (
    <Layout style={{ width: '100vw', marginLeft: '-1vw', marginTop: '-1vh', background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 头部 */}
      <Header style={{ display: 'flex', alignItems: 'center', fontSize: 20, color: 'white', background: '#001529' }}>
        <AndroidOutlined />
        <span style={{ marginLeft: '1vw' }}>
          小红书消费可视化分析系统
        </span>
        <span style={{ marginLeft: 'auto', marginRight: '1vw', color: '#fff' }}>
          你好，{userInfo?.readername}
        </span>
      </Header>

      {/* 内容部分 */}
      <Layout>
        {/* 侧边栏 */}
        <Sider 
          width={220} 
          style={{ background: '#001529', height: 'calc(100vh)', position: 'fixed', left: 0, top: 64 }}
          breakpoint="lg"
          collapsedWidth="0"
        >
          <Menu
            theme="dark"
            mode="inline"
            selectedKeys={[String(currentPage)]}
            items={items}
          />
        </Sider>

        {/* 主内容区域 */}
        <Layout style={{ marginLeft: 220, padding: '0 24px 24px', background: '#f5f5f5' }}>
          <Breadcrumb style={{ margin: '16px 0' }}>
            <Breadcrumb.Item>小红书消费可视化分析系统</Breadcrumb.Item>
            {(currentPage >= 1 && currentPage <= 6) && (
              <Breadcrumb.Item>数据一览</Breadcrumb.Item>
            )}
            <Breadcrumb.Item>
              {((currentPage === 1) && "消费区间分析") ||
                ((currentPage === 2) && "消费人群统计") ||
                ((currentPage === 3) && "活动消费统计") ||
                ((currentPage === 4) && "第三方消费分析") ||
                ((currentPage === 5) && "购物时区分析") ||
                ((currentPage === 6) && "图书出版排名") ||
                ((currentPage === 7) && "个人信息") ||
                ((currentPage === 8) && "用户管理") ||
                ((currentPage === 0) && "首页")}
            </Breadcrumb.Item>
          </Breadcrumb>

          <Content
            style={{
              padding: 24,
              margin: 0,
              minHeight: 280,
              background: colorBgContainer,
            }}
          >
            <Outlet />
          </Content>
        </Layout>
      </Layout>

      {/* 底部 */}
      <Footer style={{ textAlign: 'center' }}>©2024 Created by 郭子铭</Footer>
    </Layout>
  );
};

export default MenuLayout;
