/* eslint-disable */
import './login.scss';
import React from 'react';
import { useState,useEffect,FC } from 'react'
import { Button ,Card ,Form,Input,InputNumber, message} from 'antd';
import { Table } from 'antd';
import type { ColumnsType, TableProps } from 'antd/es/table';
import type { PaginationProps } from 'antd';
import { Pagination , Space} from 'antd';
import { Outlet,useNavigate } from 'react-router-dom';
import{bac }from '../../assets/bac2.png'


import {userID} from '../../recoil/store'
import { userState } from '../../recoil/user';

import { useRecoilState } from 'recoil';



import {gql, useQuery,useLazyQuery ,useMutation} from '@apollo/client';



const FIND_A = gql`
  query FindReaderAll($pageNumber: Int!, $pageSize: Int!) {
    findReaderAll(pageNumber: $pageNumber, pageSize: $pageSize) {
      list {
        readername
        readertype
        readersex
        email
        admin
        password
        role
        userid
      }
      totalCount
    }
  }
`;

const useLoadReaders = () => {
  const { data, loading, error } = useQuery(FIND_A, {
    variables: { pageNumber: 1, pageSize: 100 },
    onCompleted(data) {
      console.log("数据请求已发送");
      console.log(data);
    },
    onError(error) {
      console.error("请求错误:", error);
    },
  });

  return { data, loading, error };
};



const Home:FC=()=>{

  const [ID, setID] = useRecoilState(userID);
  const [userInfo, setUserInfo] = useRecoilState(userState); // 使用新的 atom



  const { data, loading, error } = useLoadReaders();
  const [messageApi, contextHolder] = message.useMessage();
  const [form] = Form.useForm();
  const nav = useNavigate()

  function nav0(){nav('/show1');
}

const onFinish = async (values) => {
  if (loading || error) {
    messageApi.open({
      type: 'error',
      content: '正在加载数据或发生错误',
    });
    return;
  }

  const user = data.findReaderAll.list.find(user => user.admin === values.admin);

  if (user && user.password === values.password) {
    messageApi.open({
      type: 'success',
      content: '登录成功',
    });


    console.log(user)
    setID(user.id); 
    setUserInfo(user); 


    nav0();
  } else {
    messageApi.open({
      type: 'error',
      content: '登录失败',
    });
  }
};


  const imageStyle = {  
    backgroundImage: `url(../../assets/bac2.png)`,  
    // 如果你想设置图片的位置，你可以使用 'background-position' 属性  
    // backgroundPosition: 'center', // 或者 '50% 50%'  
  };  

  return (
<div className="login-container">
    <div className="login-floating"></div> {/* 用于显示背景插图 */}
    {contextHolder}
    <Space direction="vertical" size={16}>
        <Card size="default" style={{ width: 350, marginLeft:'60vw', marginTop:'-20vh' }}>
            <h2 style={{ marginTop:'-1vh',marginLeft:'1vw'}}>小红书消费可视化分析系统</h2>
            <Form form={form} name="control-hooks" onFinish={onFinish} style={{marginTop:'3vw', maxWidth:600 }}>
                <div style={{marginTop:'-15px',marginBottom:'5px'}}>账号</div>
                <Form.Item name="admin">
                    <Input />
                </Form.Item>
                <div style={{marginTop:'-15px',marginBottom:'5px'}}>密码</div>
                <Form.Item name="password">
                    <Input.Password />
                </Form.Item>
                <Form.Item>
                    <Button type="primary" htmlType="submit" style={{width:302}}>登录</Button>
                </Form.Item>
            </Form>
        </Card>
    </Space>

    <div>
        <p style={{ marginTop:'60vh',marginLeft:'-55vw',color:'white'}}>©2024 Created by 郭子铭</p>
    </div>

</div>




  );
}


export default Home