/* eslint-disable */

import React from 'react';
import { useState,useEffect,FC } from 'react'
import { Button, Form, Input, Modal, Select } from 'antd';
import { Table, Card } from 'antd';
import type { ColumnsType, TableProps } from 'antd/es/table';
import type { PaginationProps } from 'antd';
import { Pagination , Space,message} from 'antd';
import { Outlet,useNavigate } from 'react-router-dom';
const { Option } = Select;

import {userID} from '../../recoil/store'
import { useRecoilState } from 'recoil';

import {gql, useQuery,useLazyQuery ,useMutation} from '@apollo/client';
import { userState } from '../../recoil/user';



const FIND = gql`
query FindReader($readerid: Int!) {
  findReaderById( readerid: $readerid) {
    readername
    readertype
    readersex
    email
    admin
    password
    role
  }
}
`;

const Reader:FC=()=>{

  const nav = useNavigate()

  function nav0(){
    nav('/');
}

const [userInfo, setUserInfo] = useRecoilState(userState); // 使用新的 atom

const [modalVisible, setModalVisible] = useState(false);


  const {refetch, data, loading, error } = useQuery(FIND, {
    variables: { readerid: userInfo.userid},
    onCompleted(data) {
      console.log(data);
      console.log("数据请求已发送");
    },
    onError(error) {
      console.error(error);
    },
  });



  const handleAddCancel = () => {
    setModalVisible(false);
  };
  const [form] = Form.useForm();
  const onReset = () => {
    form.resetFields();
  };


  const onFinish = async (values: any) => {
    try {
      console.log(selectedUser ? selectedUser.userid : null);
      
      const { data:a } = await add({
        variables: {
          "reader": {
            userid: userInfo.userid,
            role: userInfo.role,
            readertype: userInfo.role?'管理员':'用户',

            readername: values.readername,
            readersex: values.readersex,
            email: values.email,
            admin: values.admin,
            password: values.password,


          },
        },
      });
      // 处理返回的数据
      console.log(data);
      if (data) {

        refetch();
        setModalVisible(false);
        message.open({
          type: 'success',
          content: '操作成功',
        });
        console.log("操作成功");
        await handleRefetch(); 


        setUserInfo(user); 
      }
    } catch (error) {
      // 处理错误
      console.error(error);
    }
  };



  const ADD = gql`
  mutation add($reader: ReaderEntityInput!) {
    addReader(reader: $reader) {
      userid
      readername
    readertype
    readersex
    email
    admin
    password
    role
    }
  }
  `;
  
  const [selectedUser, setSelectedUser] = useState(null);
  const [datashow, setDatashow] = useState([]);
  const [filterValue, setFilterValue] = useState('');
  const [searchValue, setSearchValue] = useState('');
  const [text, setText] = useState('');
  const [add] = useMutation(ADD);
  
  
  const handleAdd = (record) => {
    setSelectedUser(record);
    setModalVisible(true);
  };
  
    const handleRefetch = async () => {
      try {
        const { data } = await refetch();
        if (data && data.findReaderById) {
          const filteredData = data.findReaderById;
          setDatashow(filteredData);
          console.log("Refetched Data:", filteredData);
        } else {
          console.error("Unexpected refetched data structure:", data);
        }
      } catch (error) {
        console.error("Error during refetch:", error);
      }
    };



  const handleback = () => {
    nav0()
  };

  return (
<div style={{width:'100vw',marginLeft:'-1vw',marginTop:'-4vh',background:'#f5f5f5',height:'100vh'}}>

<Space direction="vertical" size={16}>
    <Card size="default" 
     style={{ width: 400 ,marginLeft:'27vw',marginTop:'-20vh'}}>
      <h2 style={{ marginTop:'-1vh',marginLeft:'8vw'}}>个人信息</h2>


      {(data)&&(<div>
        <p>姓名: {data.findReaderById.readername}</p>
        <p>身份: {data.findReaderById.readertype}</p>
      <p>性别: {data.findReaderById.readersex}</p>
      <p>邮箱: {data.findReaderById.email}</p>
      <p>账号: {data.findReaderById.admin}</p>
      <p>密码: {data.findReaderById.password}</p>
      </div>
      )}
              <Button type="default" htmlType="submit"style={{marginTop:'2vh',width: 350 }} onClick={handleAdd}>
          修改信息
        </Button>
        <Button type="primary" htmlType="submit"style={{marginTop:'3vh',width: 350 }} onClick={handleback}>
          切换账号
        </Button>

    </Card>
  </Space>



  <Modal
        title=""
        visible={modalVisible}
        onCancel={handleAddCancel}
        footer={[
        ]}
      >
        { (
          <div>
<Form
  form={form}
  name="control-hooks"
  onFinish={onFinish}
  style={{ marginTop: '3vw', maxWidth: 600 }}
  initialValues={{
    readername: userInfo.readername,
    admin: userInfo.admin,
    password: userInfo.password,
    readersex: userInfo.readersex,
    email: userInfo.email,
  }}

>
  <div style={{ marginTop: '-20px' }}>用户名:</div>
  <Form.Item name="readername" rules={[{ required: true, message: '请输入用户名' }]}>
    <Input />
  </Form.Item>

  <div style={{ marginTop: '-20px' }}>账号:</div>
  <Form.Item name="admin" rules={[{ required: true, message: '请输入账号' }]}>
    <Input />
  </Form.Item>

  {selectedUser === null && (
    <>
      <div style={{ marginTop: '-20px' }}>密码:</div>
      <Form.Item name="password" rules={[{ required: true, message: '请输入密码' }]}>
        <Input.Password />
      </Form.Item>
    </>
  )}

  {selectedUser !== null && (
    <>
      {/* 密码字段在编辑用户时可选 */}
      <div style={{ marginTop: '-20px' }}>密码:</div>
      <Form.Item name="password">
        <Input.Password />
      </Form.Item> 
    </>
   )}


  <div style={{ marginTop: '-20px' }}>性别:</div>
  <Form.Item name="readersex" >
    <Select placeholder="选择性别" allowClear>
      <Option value="男">男</Option>
      <Option value="女">女</Option>
    </Select>
  </Form.Item>

  <div style={{ marginTop: '-20px' }}>邮箱:</div>
  <Form.Item name="email" rules={[{  type: 'email', message: '请输入有效的邮箱地址' }]}>
    <Input />
  </Form.Item>




<Form.Item>
<Button type="primary" htmlType="submit"style={{marginLeft:'260px'}}>
          提交
        </Button>
        <Button htmlType="button" onClick={onReset} style={{marginLeft:'10px'}}>
          重置
        </Button>
        <Button htmlType="button" onClick={handleAddCancel} style={{marginLeft:'10px'}}>
          取消
        </Button>
</Form.Item >

</Form>
          </div>
        )}
      </Modal>

</div>

  );
}


export default Reader