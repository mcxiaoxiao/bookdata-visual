/* eslint-disable */
import React, { FC, useEffect, useState } from 'react';
import { Button, Table, Modal, Select, Input, message,Form,InputNumber } from 'antd';
import { gql, useQuery,useMutation } from '@apollo/client';
import { CodeSandboxOutlined } from '@ant-design/icons';

import {
  PlusCircleOutlined
 
  
} from '@ant-design/icons';

const { Option } = Select;

const{TextArea} = Input;

const gradientBackground = {
  background: 'linear-gradient(to right, #8a4dff, #ff6bfe)',
  borderRadius: '20px',
  width: '97%',
  height: '120px',
  margin: '20px',
  marginTop: '10px',
  marginBottom: '30px',
  border: '1px solid #e3d4ff',
  backgroundImage: 'linear-gradient(to bottom right, #8a4dff, #ff6bfe)',
  transition: 'border-color 0.3s ease-in-out',
};

const inputStyle = {
  borderRadius: '20px',
  width: '70%',
  left:'5%',
  height: 50,
  background:'white',
  top:30,
  marginRight: '10px',
};

const buttonStyle = {
  borderRadius: '50%',
  width: 60,
  top:30,
  height: 60,
};

const User: FC = () => {
  const [messageApi, contextHolder] = message.useMessage();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible2, setModalVisible2] = useState(false);


  const [selectedUser, setSelectedUser] = useState(null);
  const [datashow, setDatashow] = useState([]);
  const [filterValue, setFilterValue] = useState('');
  const [searchValue, setSearchValue] = useState('');
  const [text, setText] = useState('');


  const FIND = gql`
  query FindReaderAll($pageNumber: Int!, $pageSize: Int!) {
    findReaderAll(pageNumber: $pageNumber, pageSize: $pageSize) {
      list {
        readername
        readertype
        readersex
        email
        admin
        password
        role
        userid
      }
      totalCount
    }
  }
`;

const DELETE = gql`
mutation Delete($id: Int!) {
  deleteReader(readerid: $id) {
    userid
    readername
  }
}
`;
const [del] = useMutation(DELETE);

const ADD = gql`
mutation add($reader: ReaderEntityInput!) {
  addReader(reader: $reader) {
    userid
    readername
  }
}
`;



const [add] = useMutation(ADD);


  const { refetch, data } = useQuery(FIND, {
    variables: { pageNumber: 1, pageSize: `100000`},
    onCompleted(data) {
      console.log(data);
      const filteredData = data.findReaderAll.list;
      setDatashow(filteredData);
      console.log(filteredData);

    },
    onError(error) {
      console.error(error);
    },
  });


  const handleRefetch = async () => {
    try {
      const { data } = await refetch();
      if (data && data.findReaderAll && data.findReaderAll.list) {
        const filteredData = data.findReaderAll.list;
        setDatashow(filteredData);
        console.log("Refetched Data:", filteredData);
      } else {
        console.error("Unexpected refetched data structure:", data);
      }
    } catch (error) {
      console.error("Error during refetch:", error);
    }
  };


  const columns = [
    {
      title: '用户名',
      dataIndex: 'readername',
      key: 'readername',
    },
    {
      title: '账号',
      dataIndex: 'admin',
      key: 'admin',
    },
    {
      title: '密码',
      dataIndex: 'password',
      key: 'password',
    },
    {
      title: '角色',
      dataIndex: 'readertype',
      key: 'readertype',
    },
    {
      title: '性别',
      dataIndex: 'readersex',
      key: 'readersex',
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: '序号',
      dataIndex: 'userid',
      key: 'userid',
    },
    {
      title: '修改',
      key: 'actions',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <Button type='default' onClick={() => handleAdd(record)}>修改</Button>
      ),
    },
    {
      title: '删除',
      key: 'actions',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <Button type='default' onClick={() => handleDelete(record)}>删除</Button>
      ),
    },
  ];


  const [form] = Form.useForm();
  const onReset = () => {
    form.resetFields();
  };


  const onFinish = async (values: any) => {
    try {
      console.log(selectedUser ? selectedUser.userid : null);
      
      const { data } = await add({
        variables: {
          "reader": {
            userid: selectedUser ? selectedUser.userid : 99999,
            readername: values.readername,
            readersex: values.readersex,
            email: values.email,
            admin: values.admin,
            password: values.password,
            role: values.role,
            readertype: values.role?'管理员':'用户',
          },
        },
      });
      // 处理返回的数据
      console.log(data);
      if (data) {

        refetch();

        setModalVisible(false);
        messageApi.open({
          type: 'success',
          content: '操作成功',
        });
        console.log("操作成功");
        await handleRefetch(); 
      }
    } catch (error) {
      // 处理错误
      console.error(error);
    }
  };
  



  const handleDeleteTrue = async () => {
    try {
      const { data } = await del({
        variables: { 
          id: selectedUser?.userid
        },
      });
      if (data) {
        setModalVisible2(false);
        messageApi.open({
          type: 'success',
          content: '删除成功',
        });
        console.log("删除成功")
        await handleRefetch(); 
      }
    } catch (error: unknown) {
      if (error instanceof Error) {
        setModalVisible2(false);
        messageApi.open({
          type: 'error',
          content: '删除失败',
        });
        console.log(error)
        
      }
    }
  };


  useEffect(() => {
    if (selectedUser) {
      form.setFieldsValue({
        readername: selectedUser.readername,
        admin: selectedUser.admin,
        readersex: selectedUser.readersex,
        email: selectedUser.email,
        role: selectedUser.role === '管理员' ? 1 : 0,
      });
    }
    if (!selectedUser) {
      form.resetFields();
    }
    
    else {
      form.resetFields();
    }
  }, [selectedUser]);


  const handleAdd2 = () => {
    form.resetFields();
    setSelectedUser(null);
    setModalVisible(true);
  };

  const handleAdd = (record) => {
    setSelectedUser(record);
    setModalVisible(true);
  };

  const handleDelete = (record) => {
    setSelectedUser(record);
    setModalVisible2(true);
  };


  const handleAddCancel = () => {
    setModalVisible(false);
  };
  const handleDeleteCancel = () => {
    setModalVisible2(false);
  };

  return (
    <div >
{contextHolder}
      <Button       style={{marginBottom:'1vw'}}
      size="large"
      type="primary"
      onClick={() => handleAdd2()}
      ><PlusCircleOutlined />新增用户</Button>

      <Table
        columns={columns}
        dataSource={datashow}
        scroll={{ x: 'max-content' }}
      />

<Modal
        title=""
        visible={modalVisible}
        onCancel={handleAddCancel}
        footer={[
        ]}
      >
        { (
          <div>
<Form
  form={form}
  name="control-hooks"
  onFinish={onFinish}
  style={{ marginTop: '3vw', maxWidth: 600 }}
  initialValues={{
    readername: selectedUser ? selectedUser.readername : '',
    admin: selectedUser ? selectedUser.admin : '',
    password: '',
    readersex: selectedUser ? selectedUser.readersex : null,
    email: selectedUser ? selectedUser.email : '',
    role: selectedUser ? (selectedUser.role === '管理员' ? 1 : 0) : null,
  }}

>
  <div style={{ marginTop: '-20px' }}>用户名:</div>
  <Form.Item name="readername" rules={[{ required: true, message: '请输入用户名' }]}>
    <Input />
  </Form.Item>

  <div style={{ marginTop: '-20px' }}>账号:</div>
  <Form.Item name="admin" rules={[{ required: true, message: '请输入账号' }]}>
    <Input />
  </Form.Item>

  {selectedUser === null && (
    <>
      <div style={{ marginTop: '-20px' }}>密码:</div>
      <Form.Item name="password" rules={[{ required: true, message: '请输入密码' }]}>
        <Input.Password />
      </Form.Item>
    </>
  )}

  {selectedUser !== null && (
    <>
      {/* 密码字段在编辑用户时可选 */}
      <div style={{ marginTop: '-20px' }}>密码（留空则不修改）:</div>
      <Form.Item name="password">
        <Input.Password />
      </Form.Item> 
    </>
   )}


  <div style={{ marginTop: '-20px' }}>性别:</div>
  <Form.Item name="readersex" >
    <Select placeholder="选择性别" allowClear>
      <Option value="男">男</Option>
      <Option value="女">女</Option>
    </Select>
  </Form.Item>

  <div style={{ marginTop: '-20px' }}>邮箱:</div>
  <Form.Item name="email" rules={[{  type: 'email', message: '请输入有效的邮箱地址' }]}>
    <Input />
  </Form.Item>


<div style={{marginTop:'-20px'}}>权限:</ div >
  <Form.Item name="role" >
    <Select placeholder="用户或管理员" allowClear>
      <Option value={1}>管理员</Option>
      <Option value={0}>用户</Option>
    </Select>
  </Form.Item>

<Form.Item>
<Button type="primary" htmlType="submit"style={{marginLeft:'260px'}}>
          提交
        </Button>
        <Button htmlType="button" onClick={onReset} style={{marginLeft:'10px'}}>
          重置
        </Button>
        <Button htmlType="button" onClick={handleAddCancel} style={{marginLeft:'10px'}}>
          取消
        </Button>
</Form.Item >

</Form>
          </div>
        )}
      </Modal>

      <Modal
        title="删除用户"
        visible={modalVisible2}
        onCancel={handleDeleteCancel}
        footer={[
          <Button key="cancel" onClick={handleDeleteCancel}>
            取消
          </Button>,
          <Button key="borrow" type="primary" onClick={handleDeleteTrue}>
            删除
          </Button>,
        ]}
      >
        {/* Modal content here */}
        {selectedUser && (
          <div>
            <p>用户名：{selectedUser.readername}</p>
            <p>你确定要删除这个用户吗?</p>
            {/* Add more book details as needed */}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default User;
