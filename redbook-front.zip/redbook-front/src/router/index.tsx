import React from 'react';
import Home from '../pages/home/Home';


import Show1 from '../pages/books/show1';
import Show2 from '../pages/books/show2';
import Show3 from '../pages/books/show3';
import Show4 from '../pages/books/show4';
import Show5 from '../pages/books/show5';
import Show6 from '../pages/books/show6';

import Reader from '../pages/reader/reader';
import MenuLayout from '../pages/home/MenuLayout'
import User from '../pages/user/user';



import {createBrowserRouter} from "react-router-dom"

const router = createBrowserRouter([
  {
    path:'/',
    element:<Home/>,
    children:[]
  },
  {
    path:'/',
    element:<MenuLayout/>,
    children:[
      {
        path:'/show1',
        element:<Show1/>
      },
      {
        path:'/show2',
        element:<Show2/>
      },
      {
        path:'/show3',
        element:<Show3/>
      },
      {
        path:'/show4',
        element:<Show4/>
      },
      {
        path:'/show5',
        element:<Show5/>
      },
      {
        path:'/show6',
        element:<Show6/>
      }
      ,
      {
        path:'/reader',
        element:<Reader/>
      }
      ,
      {
        path:'/user',
        element:<User/>
      }
    ]
    
  }
])

export default router