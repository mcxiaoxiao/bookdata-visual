package com.main.reader;

import com.main.schema.ReaderEntity;

import java.util.List;

public interface ReaderService {
    List<ReaderEntity> findReaderAll();
    ReaderEntity deleteReader(int readerid);
    ReaderEntity findReaderById(int readerid);
    ReaderEntity addReader(ReaderEntity reader);

}
