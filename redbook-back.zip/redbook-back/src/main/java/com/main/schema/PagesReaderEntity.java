package com.main.schema;

import java.util.List;

public class PagesReaderEntity {
    public List<ReaderEntity> list;
    public int totalCount;
}
