package com.main.get;

import com.main.schema.*;
import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsQuery;
import com.netflix.graphql.dgs.InputArgument;

import javax.annotation.Resource;
import java.util.List;

@DgsComponent
public class DataResolver {
    @Resource
    private DataService dataService;
    @DgsQuery
    public List<AdsBookPopularityRankEntity> findA1All(@InputArgument Integer id) {
        return dataService.findA1All();
    }
    @DgsQuery
    public List<AdsCategoryCountAnalysisEntity> findA2All(@InputArgument Integer id) {
        return dataService.findA2All();
    }
    @DgsQuery
    public List<AdsDiscountRatioAnalysisEntity> findA3All(@InputArgument Integer id) {
        return dataService.findA3All();
    }
    @DgsQuery
    public List<AdsPriceDistributionCountEntity> findA4All(@InputArgument Integer id) {
        return dataService.findA4All();
    }
    @DgsQuery
    public List<AdsPublisherPopularityRankEntity> findA5All(@InputArgument Integer id) {
        return dataService.findA5All();
    }
    @DgsQuery
    public List<AdsPublishTrendAnalysisEntity> findA6All(@InputArgument Integer id) {
        return dataService.findA6All();
    }
}


