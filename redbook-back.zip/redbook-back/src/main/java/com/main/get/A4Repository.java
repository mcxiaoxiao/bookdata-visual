package com.main.get;

import com.main.schema.AdsPriceDistributionCountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A4Repository extends JpaRepository<AdsPriceDistributionCountEntity, Integer>
{

}
