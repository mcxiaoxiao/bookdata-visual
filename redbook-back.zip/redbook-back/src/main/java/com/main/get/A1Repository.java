package com.main.get;

import com.main.schema.AdsBookPopularityRankEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A1Repository extends JpaRepository<AdsBookPopularityRankEntity, Integer>
{

}
