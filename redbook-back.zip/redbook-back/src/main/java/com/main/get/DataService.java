package com.main.get;

import com.main.schema.*;

import java.util.List;

public interface DataService {
    List<AdsBookPopularityRankEntity> findA1All();
    List<AdsCategoryCountAnalysisEntity> findA2All();
    List<AdsDiscountRatioAnalysisEntity> findA3All();
    List<AdsPriceDistributionCountEntity> findA4All();
    List<AdsPublisherPopularityRankEntity> findA5All();
    List<AdsPublishTrendAnalysisEntity> findA6All();
}
