package com.main.get;

import com.main.schema.*;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;

@Service
public class DataServiceImpl implements DataService {
    @Resource
    private A1Repository A1Repository;
    private A2Repository A2Repository;
    private A3Repository A3Repository;
    private A4Repository A4Repository;
    private A5Repository A5Repository;
    private A6Repository A6Repository;
    private EntityManager enstityManager;

    public DataServiceImpl(A1Repository A1Repository,
                           A2Repository A2Repository,
                           A3Repository A3Repository,
                           A4Repository A4Repository,
                           A5Repository A5Repository,
                           A6Repository A6Repository
    )
    {
        this.A1Repository=A1Repository;
        this.A2Repository=A2Repository;
        this.A3Repository=A3Repository;
        this.A4Repository=A4Repository;
        this.A5Repository=A5Repository;
        this.A6Repository=A6Repository;
    }

    @Override
    public List<AdsBookPopularityRankEntity> findA1All() {
        return A1Repository.findAll();
    }
    @Override
    public List<AdsCategoryCountAnalysisEntity> findA2All() {
        return A2Repository.findAll();
    }
    @Override
    public List<AdsDiscountRatioAnalysisEntity> findA3All() {
        return A3Repository.findAll();
    }
    @Override
    public List<AdsPriceDistributionCountEntity> findA4All() {
        return A4Repository.findAll();
    }
    @Override
    public List<AdsPublisherPopularityRankEntity> findA5All() {
        return A5Repository.findAll();
    }
    @Override
    public List<AdsPublishTrendAnalysisEntity> findA6All() {
        return A6Repository.findAll();
    }




//    @Override
//    public BookEntity addBook(BookEntity book) {
//        return bookRepository.save(book);
//    }
//    @Override
//    public BookEntity deleteBook(Integer id) {
//        BookEntity book=bookRepository.findById(id).orElse(null);
//        bookRepository.deleteById(id);
//        return book;
//    }
//    @Override
//    public List<BookEntity> findBookAll() {
//        return bookRepository.findAll();
//    }
//    @Override
//    public BookEntity findBookById(int id) {
//        return bookRepository.findById(id).orElse(null);
//    }
//    @Override
//    public Page<BookEntity> findBookPaginated(int pageNumber, int pageSize) {
////        pageNumber = 1;
////        pageSize = 10;
//        Pageable pageable = PageRequest.of(pageNumber-1, pageSize);
//        return bookRepository.findAll(pageable);
//    }
//
//
//
//    @Override
//    public FavoEntity addFavo(FavoEntity favo) {
//        return favoRepository.save(favo);
//    }
//    @Override
//    public FavoEntity deleteFavo(Integer id) {
//        FavoEntity favo=favoRepository.findById(id).orElse(null);
//        favoRepository.deleteById(id);
//        return favo;
//    }
//
//    @Override
//    public List<FavoEntity> findFavoAll() {
//        return favoRepository.findAll();
//    }
//    @Override
//    public Page<FavoEntity> findFavoPaginated(int pageNumber, int pageSize) {
////        pageNumber = 1;
////        pageSize = 10;
//        Pageable pageable = PageRequest.of(pageNumber-1, pageSize);
//        return favoRepository.findAll(pageable);
//    }



}
