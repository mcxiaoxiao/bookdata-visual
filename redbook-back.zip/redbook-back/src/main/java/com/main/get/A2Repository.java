package com.main.get;

import com.main.schema.AdsCategoryCountAnalysisEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A2Repository extends JpaRepository<AdsCategoryCountAnalysisEntity, Integer>
{

}
