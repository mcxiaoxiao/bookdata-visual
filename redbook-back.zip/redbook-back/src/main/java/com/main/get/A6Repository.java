package com.main.get;

import com.main.schema.AdsPublishTrendAnalysisEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A6Repository extends JpaRepository<AdsPublishTrendAnalysisEntity, Integer>
{

}
