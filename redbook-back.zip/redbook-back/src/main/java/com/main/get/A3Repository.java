package com.main.get;

import com.main.schema.AdsDiscountRatioAnalysisEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A3Repository extends JpaRepository<AdsDiscountRatioAnalysisEntity, Integer>
{

}
