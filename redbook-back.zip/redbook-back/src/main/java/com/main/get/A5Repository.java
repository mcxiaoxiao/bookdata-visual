package com.main.get;

import com.main.schema.AdsPublisherPopularityRankEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A5Repository extends JpaRepository<AdsPublisherPopularityRankEntity, Integer>
{

}
